
In order to enable your template for each category you'll need to do two things:
	1. Rename the file(s) under Definitions from *.vstemplat- to *.vstemplate
	2. Update the content in the relevant *.vstemplate files


You should also consider replacing the icon.png with one of your own.
