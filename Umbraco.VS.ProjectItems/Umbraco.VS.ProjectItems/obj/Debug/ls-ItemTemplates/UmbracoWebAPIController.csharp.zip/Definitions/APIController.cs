﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Umbraco.VS.ProjectItems.ItemTemplates.Web.Umbraco.UmbracoWebAPIController.Definitions
{
    public class APIController
    {
    }
}
